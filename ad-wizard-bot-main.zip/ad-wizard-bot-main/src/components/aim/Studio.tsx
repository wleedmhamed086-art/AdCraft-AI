import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { tools, generateCopy, type ToolId } from "./tools";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import iconUgc from "@/assets/icon-ugc.png";
import iconAds from "@/assets/icon-ads.png";
import iconScript from "@/assets/icon-script.png";
import iconTarget from "@/assets/icon-target.png";
import iconAnalytics from "@/assets/icon-analytics.png";

const icons: Record<ToolId, string> = {
  ugc: iconUgc,
  ad: iconAds,
  hooks: iconScript,
  audience: iconTarget,
  funnel: iconAnalytics,
};

const platforms = ["Meta (Instagram/Facebook)", "TikTok", "Snapchat", "YouTube Shorts"];

export function Studio() {
  const { user } = useAuth();
  const [tool, setTool] = useState<ToolId>("ugc");
  const [product, setProduct] = useState("");
  const [audience, setAudience] = useState("");
  const [platform, setPlatform] = useState<string>(platforms[0] ?? "Meta");
  const [offer, setOffer] = useState("");
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">("idle");

  const run = () => {
    if (!product.trim()) {
      setError("اكتب اسم المنتج أو الخدمة أولاً");
      setResult("");
      return;
    }
    setError("");
    setCopied(false);
    setSaveState("idle");
    setResult(generateCopy(tool, { product, audience, platform, offer }));
  };

  const copy = async () => {
    await navigator.clipboard.writeText(result);
    setCopied(true);
  };

  const save = async () => {
    if (!user) return;
    setSaveState("saving");
    const { error: err } = await supabase.from("projects").insert({
      user_id: user.id,
      tool,
      product,
      audience,
      platform,
      offer,
      result,
    });
    if (err) {
      setSaveState("idle");
      setError("تعذّر حفظ المشروع، حاول مرة أخرى");
      return;
    }
    setSaveState("saved");
  };

  const active = tools.find((t) => t.id === tool);

  return (
    <div className="grid gap-8 lg:grid-cols-[320px_1fr]">
      <div className="space-y-3">
        {tools.map((t) => {
          const isActive = t.id === tool;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTool(t.id)}
              className="block w-full text-right"
              aria-pressed={isActive}
            >
              <Card
                className={`flex flex-row items-center gap-4 rounded-2xl border p-4 transition-all hover:-translate-y-0.5 ${
                  isActive ? "border-primary bg-secondary/60 ring-2 ring-primary" : "border-border"
                }`}
                style={isActive ? { boxShadow: "var(--shadow-card)" } : undefined}
              >
                <img
                  src={icons[t.id]}
                  alt=""
                  loading="lazy"
                  width={768}
                  height={768}
                  className="h-12 w-12 shrink-0 object-contain"
                />
                <span className="min-w-0">
                  <span className="block text-base font-bold">{t.title}</span>
                  <span className="block text-xs text-muted-foreground">{t.desc}</span>
                </span>
              </Card>
            </button>
          );
        })}
      </div>

      <Card className="rounded-3xl p-6 sm:p-8" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex flex-wrap items-center gap-3">
          <h3 className="text-xl font-extrabold">{active?.title}</h3>
          <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
            {active?.badge}
          </span>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <Input
            value={product}
            onChange={(e) => setProduct(e.target.value)}
            placeholder="اسم المنتج أو الخدمة"
            className="h-12 rounded-xl"
          />
          <Input
            value={audience}
            onChange={(e) => setAudience(e.target.value)}
            placeholder="الجمهور المستهدف (مثال: أمهات جديدات)"
            className="h-12 rounded-xl"
          />
          <select
            value={platform}
            onChange={(e) => setPlatform(e.target.value)}
            className="h-12 rounded-xl border border-input bg-card px-4 text-sm text-foreground"
            aria-label="المنصة"
          >
            {platforms.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
          <Input
            value={offer}
            onChange={(e) => setOffer(e.target.value)}
            placeholder="العرض (خصم 30%، شحن مجاني...)"
            className="h-12 rounded-xl"
          />
        </div>

        {error && <p className="mt-4 text-sm font-semibold text-destructive">{error}</p>}

        <div className="mt-6 flex flex-wrap gap-3">
          <Button onClick={run} size="lg" className="rounded-xl px-8 font-bold">
            توليد المحتوى
          </Button>
          {result && (
            <Button variant="outline" size="lg" className="rounded-xl" onClick={copy}>
              {copied ? "تم النسخ ✓" : "نسخ النص"}
            </Button>
          )}
          {result &&
            (user ? (
              <Button
                variant="secondary"
                size="lg"
                className="rounded-xl font-bold"
                onClick={save}
                disabled={saveState !== "idle"}
              >
                {saveState === "saved"
                  ? "محفوظ في حسابك ✓"
                  : saveState === "saving"
                    ? "جارٍ الحفظ..."
                    : "حفظ في مشاريعي"}
              </Button>
            ) : (
              <Button asChild variant="secondary" size="lg" className="rounded-xl font-bold">
                <Link to="/auth">سجّل الدخول للحفظ</Link>
              </Button>
            ))}
        </div>

        {result ? (
          <div className="mt-6 rounded-2xl border border-border bg-secondary/50 p-5">
            <p className="whitespace-pre-wrap text-sm leading-8 text-foreground">{result}</p>
          </div>
        ) : (
          <p className="mt-6 rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
            املأ البيانات واضغط توليد المحتوى لتظهر النتيجة هنا.
          </p>
        )}
      </Card>
    </div>
  );
}
