import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Studio } from "@/components/aim/Studio";
import { useAuth } from "@/hooks/useAuth";
import iconUgc from "@/assets/icon-ugc.png";
import iconAds from "@/assets/icon-ads.png";
import iconScript from "@/assets/icon-script.png";
import iconTarget from "@/assets/icon-target.png";
import iconAnalytics from "@/assets/icon-analytics.png";
import iconRocket from "@/assets/icon-rocket.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "UGC Ads Studio | منصة محتوى الإعلانات الممولة" },
      {
        name: "description",
        content:
          "منصة SaaS للمسوقين والتجار وأصحاب الإعلانات الممولة: سكربتات UGC، نصوص إعلانات Meta و TikTok، هوكات، واستهداف جاهز في دقائق.",
      },
      { property: "og:title", content: "UGC Ads Studio | إعلانات ممولة بتقنية UGC" },
      {
        property: "og:description",
        content:
          "ولّد سكربتات UGC ونصوص إعلانات وخطط استهداف احترافية للمسوقين والتجار وأصحاب الحملات الممولة.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const stats = [
  { value: "+٣٢٠٠", label: "مسوّق وتاجر" },
  { value: "×٤.١", label: "متوسط تحسّن CTR" },
  { value: "٤٥ ثانية", label: "لإنتاج سكربت UGC" },
  { value: "٥ منصات", label: "Meta · TikTok · Snap · YT" },
];

const features = [
  {
    icon: iconUgc,
    title: "محرك UGC حقيقي",
    text: "سكربتات بأسلوب العميل العادي مع توقيتات وهوكات ولقطات تصوير جاهزة للمبدع.",
  },
  {
    icon: iconAds,
    title: "نسخ إعلانية متعددة",
    text: "عناوين ونصوص وأزرار حث مهيأة لكل منصة وسياستها الإعلانية.",
  },
  {
    icon: iconTarget,
    title: "استهداف جاهز",
    text: "شرائح باردة و Lookalike وإعادة استهداف مع توزيع ميزانية مقترح.",
  },
  {
    icon: iconScript,
    title: "مكتبة هوكات",
    text: "بدايات ثلاث ثوانٍ مختبرة توقف التمرير وترفع نسبة المشاهدة.",
  },
  {
    icon: iconAnalytics,
    title: "قياس ما يعمل",
    text: "هيكل اختبار A/B واضح: ٣ هوكات لكل زاوية، وقرارات على أساس البيانات.",
  },
  {
    icon: iconRocket,
    title: "من الفكرة للإطلاق",
    text: "بريف واحد يخرج لك السكربت والإعلان وصفحة الهبوط في مسار واحد.",
  },
];

const steps = [
  { n: "١", t: "اكتب البريف", d: "المنتج، الجمهور، المنصة، والعرض." },
  { n: "٢", t: "اختر الأداة", d: "UGC، إعلان ممول، هوكات، استهداف أو صفحة هبوط." },
  { n: "٣", t: "ولّد وعدّل", d: "نسخة كاملة جاهزة للتصوير أو النشر مباشرة." },
  { n: "٤", t: "أطلق واختبر", d: "ارفع ٣ نسخ واختبرها وطوّر الرابح." },
];

const plans = [
  {
    name: "بداية",
    price: "٠",
    period: "مجاناً",
    items: ["١٠ توليدات شهرياً", "أداتان", "منصة واحدة", "نسخ ولصق"],
    cta: "ابدأ مجاناً",
    featured: false,
  },
  {
    name: "احترافي",
    price: "٩٩",
    period: "ريال / شهرياً",
    items: ["توليدات غير محدودة", "كل الأدوات الخمس", "كل المنصات", "مكتبة هوكات كاملة", "خطط استهداف"],
    cta: "اشترك الآن",
    featured: true,
  },
  {
    name: "وكالة",
    price: "٢٩٩",
    period: "ريال / شهرياً",
    items: ["حتى ١٠ عملاء", "مساحات عمل منفصلة", "قوالب بهوية العميل", "دعم أولوية"],
    cta: "تواصل معنا",
    featured: false,
  },
];

const testimonials = [
  {
    q: "أول مرة أوقف التصوير العشوائي. السكربتات جاهزة والمبدع يصوّر بدون نقاش.",
    n: "منى الحربي",
    r: "مالكة متجر عناية",
  },
  {
    q: "خفّضت تكلفة النتيجة بأكثر من الثلث لأن الهوكات صارت مختبرة مسبقاً.",
    n: "ياسر عبدالله",
    r: "مشتري إعلانات Meta",
  },
  {
    q: "نشتغل على ٧ عملاء، والمنصة صارت الخطوة الأولى في كل حملة جديدة.",
    n: "وكالة نمو",
    r: "وكالة تسويق أداء",
  },
];

const faqs = [
  {
    q: "لمن هذه المنصة؟",
    a: "للمسوقين بالأداء، أصحاب المتاجر الإلكترونية، مشتري الإعلانات، والوكالات التي تنتج محتوى UGC بشكل متكرر.",
  },
  {
    q: "هل المحتوى جاهز للنشر مباشرة؟",
    a: "نعم، مع توصية بمراجعة سريعة لملاءمة نبرة علامتك وسياسة المنصة الإعلانية.",
  },
  {
    q: "هل أحتاج مبدعي محتوى؟",
    a: "السكربت يعمل مع أي مبدع أو حتى تصوير ذاتي بالهاتف، لأنه يحدد اللقطات والتوقيت.",
  },
  {
    q: "هل يمكن الإلغاء في أي وقت؟",
    a: "نعم، الاشتراك شهري بدون التزام طويل الأمد.",
  },
];

function Index() {
  const { user, signOut } = useAuth();
  const goStudio = () =>
    document.getElementById("studio")?.scrollIntoView({ behavior: "smooth" });

  return (
    <main className="min-h-screen bg-background">
      <nav className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2">
            <img src={iconRocket} alt="" width={768} height={768} className="h-9 w-9 object-contain" />
            <span className="text-lg font-extrabold">UGC Ads Studio</span>
          </div>
          <div className="hidden items-center gap-7 text-sm font-semibold text-muted-foreground md:flex">
            <a href="#features" className="hover:text-foreground">المزايا</a>
            <a href="#studio" className="hover:text-foreground">الاستوديو</a>
            <a href="#pricing" className="hover:text-foreground">الأسعار</a>
            <a href="#faq" className="hover:text-foreground">الأسئلة</a>
          </div>
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <Button asChild variant="outline" className="rounded-xl font-bold">
                  <Link to="/projects">مشاريعي</Link>
                </Button>
                <Button variant="ghost" className="rounded-xl" onClick={signOut}>
                  خروج
                </Button>
              </>
            ) : (
              <Button asChild variant="outline" className="rounded-xl font-bold">
                <Link to="/auth">تسجيل الدخول</Link>
              </Button>
            )}
            <Button onClick={goStudio} className="rounded-xl font-bold">ابدأ مجاناً</Button>
          </div>
        </div>
      </nav>

      <header className="relative overflow-hidden text-primary-foreground" style={{ background: "var(--gradient-hero)" }}>
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 lg:grid-cols-2 lg:py-28">
          <div>
            <span className="inline-block rounded-full bg-primary-foreground/15 px-4 py-1.5 text-xs font-bold">
              منصة SaaS لمحتوى الإعلانات الممولة
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight sm:text-5xl">
              إعلانات ممولة بتقنية UGC تُنتج في دقائق
            </h1>
            <p className="mt-5 max-w-xl text-base leading-8 opacity-90">
              مصمّمة للمسوقين والتجار وأصحاب الحملات الممولة: سكربتات UGC، نصوص إعلانات لكل منصة،
              هوكات مختبرة، وخطط استهداف — من بريف واحد.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button size="lg" variant="secondary" onClick={goStudio} className="rounded-xl px-8 text-base font-bold">
                جرّب الاستوديو الآن
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="rounded-xl border-primary-foreground/40 bg-transparent px-8 text-base font-bold text-primary-foreground hover:bg-primary-foreground/10"
                onClick={() => document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" })}
              >
                شاهد الخطط
              </Button>
            </div>
            <div className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-4">
              {stats.map((s) => (
                <div key={s.label}>
                  <p className="text-2xl font-extrabold">{s.value}</p>
                  <p className="text-xs opacity-80">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative mx-auto grid w-full max-w-md grid-cols-2 gap-6">
            {[iconUgc, iconAds, iconTarget, iconAnalytics].map((src, i) => (
              <div
                key={i}
                className="rounded-3xl bg-primary-foreground/10 p-6 backdrop-blur"
                style={{ boxShadow: "var(--shadow-3d)" }}
              >
                <img
                  src={src}
                  alt="أيقونة ثلاثية الأبعاد لأدوات إنتاج إعلانات UGC"
                  width={768}
                  height={768}
                  className="icon-3d h-24 w-full object-contain"
                  style={{ animationDelay: `${i * 0.4}s` }}
                />
              </div>
            ))}
          </div>
        </div>
      </header>

      <section id="features" className="mx-auto max-w-6xl px-5 py-20">
        <h2 className="text-center text-3xl font-extrabold">كل ما تحتاجه حملتك الممولة</h2>
        <p className="mx-auto mt-3 max-w-2xl text-center text-muted-foreground">
          منظومة واحدة تغطي المحتوى والنسخة الإعلانية والاستهداف، بدل خمس أدوات متفرقة.
        </p>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <Card
              key={f.title}
              className="rounded-3xl border-border p-7 transition-transform hover:-translate-y-1"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <img src={f.icon} alt="" loading="lazy" width={768} height={768} className="icon-3d h-16 w-16 object-contain" />
              <h3 className="mt-5 text-lg font-bold">{f.title}</h3>
              <p className="mt-2 text-sm leading-7 text-muted-foreground">{f.text}</p>
            </Card>
          ))}
        </div>
      </section>

      <section className="border-y border-border" style={{ background: "var(--gradient-soft)" }}>
        <div className="mx-auto max-w-6xl px-5 py-20">
          <h2 className="text-center text-3xl font-extrabold">كيف تعمل المنصة</h2>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map((s) => (
              <Card key={s.n} className="rounded-3xl border-border p-7" style={{ boxShadow: "var(--shadow-card)" }}>
                <span
                  className="flex h-12 w-12 items-center justify-center rounded-2xl text-lg font-extrabold text-primary-foreground"
                  style={{ background: "var(--gradient-primary)" }}
                >
                  {s.n}
                </span>
                <h3 className="mt-5 text-lg font-bold">{s.t}</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{s.d}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="studio" className="mx-auto max-w-6xl px-5 py-20">
        <h2 className="text-center text-3xl font-extrabold">الاستوديو</h2>
        <p className="mx-auto mt-3 max-w-2xl text-center text-muted-foreground">
          اختر الأداة، اكتب البريف، واحصل على مخرجات جاهزة للتصوير أو النشر.
        </p>
        <div className="mt-12">
          <Studio />
        </div>
      </section>

      <section id="pricing" className="border-y border-border" style={{ background: "var(--gradient-soft)" }}>
        <div className="mx-auto max-w-6xl px-5 py-20">
          <h2 className="text-center text-3xl font-extrabold">خطط تناسب حجم إعلاناتك</h2>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {plans.map((p) => (
              <Card
                key={p.name}
                className={`relative rounded-3xl p-8 ${p.featured ? "border-primary ring-2 ring-primary" : "border-border"}`}
                style={{ boxShadow: p.featured ? "var(--shadow-3d)" : "var(--shadow-card)" }}
              >
                {p.featured && (
                  <span className="absolute -top-3 right-8 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
                    الأكثر اختياراً
                  </span>
                )}
                <h3 className="text-lg font-bold">{p.name}</h3>
                <p className="mt-4 text-4xl font-extrabold">{p.price}</p>
                <p className="text-sm text-muted-foreground">{p.period}</p>
                <ul className="mt-6 space-y-3 text-sm">
                  {p.items.map((i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="text-primary">✓</span>
                      <span className="text-muted-foreground">{i}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  onClick={goStudio}
                  variant={p.featured ? "default" : "outline"}
                  className="mt-8 w-full rounded-xl font-bold"
                  size="lg"
                >
                  {p.cta}
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20">
        <h2 className="text-center text-3xl font-extrabold">يعتمد عليها مشترو الإعلانات</h2>
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {testimonials.map((t) => (
            <Card key={t.n} className="rounded-3xl border-border p-7" style={{ boxShadow: "var(--shadow-card)" }}>
              <p className="text-sm leading-8">”{t.q}“</p>
              <p className="mt-6 text-sm font-bold">{t.n}</p>
              <p className="text-xs text-muted-foreground">{t.r}</p>
            </Card>
          ))}
        </div>
      </section>

      <section id="faq" className="border-t border-border" style={{ background: "var(--gradient-soft)" }}>
        <div className="mx-auto max-w-3xl px-5 py-20">
          <h2 className="text-center text-3xl font-extrabold">الأسئلة الشائعة</h2>
          <div className="mt-10 space-y-4">
            {faqs.map((f) => (
              <details key={f.q} className="rounded-2xl border border-border bg-card p-5">
                <summary className="cursor-pointer text-base font-bold">{f.q}</summary>
                <p className="mt-3 text-sm leading-7 text-muted-foreground">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20">
        <Card
          className="flex flex-col items-center gap-6 rounded-3xl border-0 p-12 text-center text-primary-foreground"
          style={{ background: "var(--gradient-hero)", boxShadow: "var(--shadow-glow)" }}
        >
          <img src={iconRocket} alt="" loading="lazy" width={768} height={768} className="icon-3d h-24 w-24 object-contain" />
          <h2 className="text-3xl font-extrabold">أطلق حملتك القادمة بمحتوى UGC أقوى</h2>
          <p className="max-w-xl opacity-90">ابدأ مجاناً الآن، بدون بطاقة بنكية، وولّد أول سكربت خلال دقيقة.</p>
          <Button size="lg" variant="secondary" onClick={goStudio} className="rounded-xl px-10 text-base font-bold">
            ابدأ الآن مجاناً
          </Button>
        </Card>
      </section>

      <footer className="border-t border-border py-10 text-center text-sm text-muted-foreground">
        © 2026 UGC Ads Studio — منصة محتوى الإعلانات الممولة للمسوقين والتجار
      </footer>
    </main>
  );
}
