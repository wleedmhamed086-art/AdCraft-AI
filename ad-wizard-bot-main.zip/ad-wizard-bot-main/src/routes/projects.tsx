import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { tools } from "@/components/aim/tools";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "مشاريعي المحفوظة | UGC Ads Studio" },
      {
        name: "description",
        content: "كل سكربتات UGC ونصوص الإعلانات الممولة التي ولّدتها محفوظة في حسابك ومتاحة في أي وقت.",
      },
      { property: "og:title", content: "مشاريعي المحفوظة | UGC Ads Studio" },
      {
        property: "og:description",
        content: "استعرض وأدر مشاريع الإعلانات وسكربتات UGC المحفوظة داخل حسابك.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProjectsPage,
});

type Project = {
  id: string;
  tool: string;
  product: string;
  audience: string | null;
  platform: string | null;
  offer: string | null;
  result: string;
  created_at: string;
};

function ProjectsPage() {
  const navigate = useNavigate();
  const { user, loading, signOut } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  const [profileName, setProfileName] = useState("");

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const [{ data, error: err }, { data: profile }] = await Promise.all([
        supabase
          .from("projects")
          .select("id, tool, product, audience, platform, offer, result, created_at")
          .order("created_at", { ascending: false }),
        supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle(),
      ]);
      if (cancelled) return;
      if (err) setError("تعذّر تحميل المشاريع");
      setProjects((data as Project[] | null) ?? []);
      setProfileName(profile?.display_name ?? "");
      setBusy(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const remove = async (id: string) => {
    const { error: err } = await supabase.from("projects").delete().eq("id", id);
    if (err) {
      setError("تعذّر حذف المشروع");
      return;
    }
    setProjects((prev) => prev.filter((p) => p.id !== id));
  };

  const toolTitle = (id: string) => tools.find((t) => t.id === id)?.title ?? id;

  return (
    <main className="min-h-screen bg-background">
      <nav className="border-b border-border/60">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <Link to="/" className="text-lg font-extrabold">
            UGC Ads Studio
          </Link>
          <div className="flex items-center gap-3">
            <Link to="/" className="text-sm font-semibold text-muted-foreground hover:text-foreground">
              الاستوديو
            </Link>
            <Button variant="outline" className="rounded-xl" onClick={signOut}>
              خروج
            </Button>
          </div>
        </div>
      </nav>

      <section className="mx-auto max-w-5xl px-5 py-12">
        <h1 className="text-3xl font-extrabold">
          مشاريعي المحفوظة{profileName ? ` — ${profileName}` : ""}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          كل ما تولّده في الاستوديو يمكن حفظه هنا والرجوع إليه لاحقاً.
        </p>

        {error && <p className="mt-4 text-sm font-semibold text-destructive">{error}</p>}

        {busy ? (
          <p className="mt-10 text-sm text-muted-foreground">جارٍ التحميل...</p>
        ) : projects.length === 0 ? (
          <Card className="mt-10 rounded-3xl border-dashed p-10 text-center">
            <p className="text-sm text-muted-foreground">لا توجد مشاريع محفوظة بعد.</p>
            <Button asChild className="mt-5 rounded-xl font-bold">
              <Link to="/">ابدأ التوليد الآن</Link>
            </Button>
          </Card>
        ) : (
          <div className="mt-8 space-y-4">
            {projects.map((p) => (
              <Card key={p.id} className="rounded-2xl p-5" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
                      {toolTitle(p.tool)}
                    </span>
                    <h2 className="mt-3 text-lg font-bold">{p.product}</h2>
                    <p className="text-xs text-muted-foreground">
                      {[p.platform, p.audience, p.offer].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="rounded-xl"
                      onClick={() => navigator.clipboard.writeText(p.result)}
                    >
                      نسخ
                    </Button>
                    <Button variant="destructive" className="rounded-xl" onClick={() => remove(p.id)}>
                      حذف
                    </Button>
                  </div>
                </div>
                <p className="mt-4 whitespace-pre-wrap rounded-xl bg-secondary/50 p-4 text-sm leading-8">
                  {p.result}
                </p>
              </Card>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}