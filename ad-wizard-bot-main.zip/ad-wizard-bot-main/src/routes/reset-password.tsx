import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "تعيين كلمة مرور جديدة | UGC Ads Studio" },
      {
        name: "description",
        content: "اختر كلمة مرور جديدة لحسابك في UGC Ads Studio واستعد الوصول إلى مشاريعك المحفوظة.",
      },
      { property: "og:title", content: "تعيين كلمة مرور جديدة | UGC Ads Studio" },
      {
        property: "og:description",
        content: "استعادة كلمة المرور والعودة إلى مشاريع الإعلانات المحفوظة في حسابك.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (password !== confirm) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    setBusy(true);
    const { error: err } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (err) {
      setError(err.message);
      return;
    }
    setDone(true);
    setTimeout(() => navigate({ to: "/projects" }), 1200);
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-5 py-16">
      <Card className="w-full max-w-md rounded-3xl p-7" style={{ boxShadow: "var(--shadow-card)" }}>
        <h1 className="text-2xl font-extrabold">تعيين كلمة مرور جديدة</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          اكتب كلمة المرور الجديدة لحسابك ثم احفظها.
        </p>

        {done ? (
          <p className="mt-6 text-sm font-semibold text-primary">
            تم تحديث كلمة المرور بنجاح، جارٍ تحويلك...
          </p>
        ) : (
          <form onSubmit={submit} className="mt-6 space-y-4">
            <Input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="كلمة المرور الجديدة"
              className="h-12 rounded-xl"
            />
            <Input
              type="password"
              required
              minLength={6}
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="تأكيد كلمة المرور"
              className="h-12 rounded-xl"
            />
            {error && <p className="text-sm font-semibold text-destructive">{error}</p>}
            <Button type="submit" disabled={busy} size="lg" className="w-full rounded-xl font-bold">
              {busy ? "جارٍ الحفظ..." : "حفظ كلمة المرور"}
            </Button>
          </form>
        )}

        <Link
          to="/auth"
          className="mt-6 block text-center text-sm font-semibold text-muted-foreground hover:text-foreground"
        >
          العودة لتسجيل الدخول
        </Link>
      </Card>
    </main>
  );
}