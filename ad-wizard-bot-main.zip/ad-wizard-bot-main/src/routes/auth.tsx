import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "تسجيل الدخول | UGC Ads Studio" },
      {
        name: "description",
        content:
          "سجّل الدخول أو أنشئ حساباً في UGC Ads Studio لحفظ مشاريع الإعلانات وسكربتات UGC الخاصة بك.",
      },
      { property: "og:title", content: "تسجيل الدخول | UGC Ads Studio" },
      {
        property: "og:description",
        content: "حساب مجاني لحفظ مشاريعك وسكربتات UGC ونصوص إعلاناتك الممولة.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "forgot";

function AuthPage() {
  const navigate = useNavigate();
  const { session } = useAuth();
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (session) navigate({ to: "/projects" });
  }, [session, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setInfo("");
    setBusy(true);
    try {
      if (mode === "forgot") {
        const { error: err } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (err) throw err;
        setInfo("أرسلنا رابط استعادة كلمة المرور إلى بريدك. تحقّق من صندوق الوارد.");
      } else if (mode === "signup") {
        const { error: err } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { display_name: displayName, business_name: businessName },
          },
        });
        if (err) throw err;
        setInfo("تم إنشاء الحساب بنجاح.");
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email, password });
        if (err) throw err;
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "حدث خطأ غير متوقع");
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setError("");
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError("تعذّر تسجيل الدخول بجوجل، حاول مرة أخرى.");
      return;
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-5 py-16">
      <Card className="w-full max-w-md rounded-3xl p-7" style={{ boxShadow: "var(--shadow-card)" }}>
        <Link to="/" className="text-sm font-semibold text-muted-foreground hover:text-foreground">
          ← الرجوع للرئيسية
        </Link>
        <h1 className="mt-4 text-2xl font-extrabold">
          {mode === "signin"
            ? "تسجيل الدخول"
            : mode === "signup"
              ? "إنشاء حساب جديد"
              : "استعادة كلمة المرور"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {mode === "forgot"
            ? "اكتب بريدك وسنرسل لك رابط تعيين كلمة مرور جديدة."
            : "احفظ مشاريعك وسكربتات UGC داخل حسابك."}
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {mode === "signup" && (
            <>
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="الاسم الظاهر"
                className="h-12 rounded-xl"
              />
              <Input
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="اسم النشاط التجاري (اختياري)"
                className="h-12 rounded-xl"
              />
            </>
          )}
          <Input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="البريد الإلكتروني"
            className="h-12 rounded-xl"
          />
          {mode !== "forgot" && (
            <Input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="كلمة المرور"
              className="h-12 rounded-xl"
            />
          )}

          {error && <p className="text-sm font-semibold text-destructive">{error}</p>}
          {info && <p className="text-sm font-semibold text-primary">{info}</p>}

          <Button type="submit" disabled={busy} size="lg" className="w-full rounded-xl font-bold">
            {busy
              ? "جارٍ التنفيذ..."
              : mode === "signin"
                ? "دخول"
                : mode === "signup"
                  ? "إنشاء الحساب"
                  : "إرسال الرابط"}
          </Button>
        </form>

        {mode !== "forgot" && (
          <>
            <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
              <span className="h-px flex-1 bg-border" />
              أو
              <span className="h-px flex-1 bg-border" />
            </div>
            <Button variant="outline" size="lg" className="w-full rounded-xl" onClick={google}>
              المتابعة عبر Google
            </Button>
          </>
        )}

        <div className="mt-6 space-y-2 text-center text-sm">
          {mode === "signin" && (
            <>
              <button
                type="button"
                className="font-semibold text-primary hover:underline"
                onClick={() => {
                  setMode("forgot");
                  setError("");
                  setInfo("");
                }}
              >
                نسيت كلمة المرور؟
              </button>
              <p className="text-muted-foreground">
                لا تملك حساباً؟{" "}
                <button
                  type="button"
                  className="font-semibold text-primary hover:underline"
                  onClick={() => setMode("signup")}
                >
                  أنشئ حساباً
                </button>
              </p>
            </>
          )}
          {mode !== "signin" && (
            <button
              type="button"
              className="font-semibold text-primary hover:underline"
              onClick={() => {
                setMode("signin");
                setError("");
                setInfo("");
              }}
            >
              العودة لتسجيل الدخول
            </button>
          )}
        </div>
      </Card>
    </main>
  );
}